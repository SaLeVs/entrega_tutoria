This is some landscape textures from Rayman Legends ripped by NoobaGutt.

www.youtube.com/user/NoobaGutt